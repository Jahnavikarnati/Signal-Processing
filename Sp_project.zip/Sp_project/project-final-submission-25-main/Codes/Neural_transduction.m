function ycn = Neural_transduction(xcn,fs)
%Here each subband signal is compressed, full wave rectified and low pass
%filterd

ycn = zeros(70,length(xcn));
for c = 1:70
fc = 229*(10^((2.3+0.39*c)/21.4) - 1);
%Here compression is done by multipying the each subband signal with a
%factor that depends on standard deviation of the suband signal.
%std returns the standard deviation the signal.
sigma = std(xcn(c,:));
gamma = sigma^(0.33-1);
h = gamma*xcn(c,:);
%Now the resulting signal is full wave rectified and low pass filtered with
%passband frequency fc. 
y = abs(h);
yc = lowpass(y,fc,fs);
%Then we add this signal to the compressed signal and scale it by a factor
%2.
ycn(c,:) = (yc+h)/2;

end
end