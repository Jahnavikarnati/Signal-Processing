%consider a imput signal of three pitches 60Hz, 75Hz,100hz using harmonics
%function derived in lab 6 
Fs = 1000 ;
N = 5;
f0 =60 ;
P = zeros(1,N);
td = 1 ;

A = zeros(1,N);
for k = 1:N
    A(k) = 1/k;
end


xn1 = harmonics(A,f0,P,td,Fs);

Fs = 1000 ;
N = 5;
f0 =75 ;
P = zeros(1,N);
td = 1 ;

A = zeros(1,N);
for k = 1:N
    A(k) = 1/k;
end


xn2 = harmonics(A,f0,P,td,Fs);

 Fs = 1000 ;
N = 5;
f0 = 100;
P = zeros(1,N);
td = 1 ;

A = zeros(1,N);
for k = 1:N
    A(k) = 1/k;
end


xn3 = harmonics(A,f0,P,td,Fs);
xn=xn1+xn2+xn3;
%Fs = 8000;
%n = 0:1/Fs:4;
% take a signal with three different frequencies
%xn = sin(w0*n)+sin(w1*n)+sin(w3*n)+randn(size(n));
%xn=xn(:,1)';
 
ln=length(xn);
N=0:Fs*1/ln:(1-1/ln)*Fs;
%pass the signal through auditory filter bank
xcn =Filter_bank(xn,Fs); 

 %pass the output signals through neural transduction stage 
ycn = Neural_transduction(xcn,Fs);
% combining all the channels to get summary spectrum(freq domain of ACF)
Uk = ACF_freq(ycn);
rt = ifft(Uk);%rt is acf of input signal
%from the plot of Uk we can observe the fundamental frequencies 
figure; plot(N,Uk);
xlabel('frequency(Hz)');
ylabel('Ut(k)');
title('peaks will give us the fundamental frequencies')
