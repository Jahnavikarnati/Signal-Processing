function xt = SumOfSines(A,F,P,td,fs)
t = 0:1/fs:td ;
n = length(A);
xt = zeros((size(t)));
for k = 1:n
xt = A(k)*sin(2*pi*F(k)*t + P(k)) + xt;
end
end