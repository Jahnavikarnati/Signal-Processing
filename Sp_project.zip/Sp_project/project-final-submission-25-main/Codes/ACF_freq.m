function Uk = ACF_freq(ycn)
%Now we will be calculating the summary spectrum from ycn the output
%subband signals after the neural transduction process.
n = length(ycn);
a = zeros(70,n);
Uk = zeros(1,n);
for c = 1:70
    uk = fft(ycn(c,:),n);%We will be computing the dft of ycn
%Then we take the absolute of the resulting dft function and raise it to the power 2 .
    a(c,:) = abs(uk); 
% By adding all the resulting subband signals we get the summary spectrum.
    Uk = Uk+(a(c,:).^2);   
end

end
