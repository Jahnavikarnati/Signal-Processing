function xcn = Filter_bank(xn,fs)
% This is an auditory filter bank function where we pass the input signal
% to the filter bank.
J = 2;% Here we do cascading of 2 IIR filters so thats why we have taken
%the value of J as 2.
% In the auditory filter bak we will be having 70 channels.Therefore we
% will be getting 70 subband signals from the filter bank.
xcn = zeros(70,length(xn));
for c = 1:70
% The vaue of center frequencies of each band is specified as below.
fc = 229*(10^((2.3+0.39*c)/21.4) - 1);
wc = 2*pi*fc;
bc = 0.108*fc + 24.7;
bc3 = 2*1.019*bc*sqrt(2^(1/4) - 1);
A = exp(-bc3*pi/(fs*sqrt(2^(1/J)-1)));
w1 = ((1+A^2)*cos(wc)/2*A);
w2 = (2*A*cos(wc)/(1+A^2));
p1 = (1-A^2)/2;
p2 = (1-A^2)*sqrt(1-(w2)^2);
%Here we will do cascading of 2 resonators H1(z) and H2(z) we will bw
%multiplying these 2 and get the numerator and denominator coefficents of
%the resulting filter.
b = [p1*p2 0 -p1*p2];
a = [1 -(A)*(w1+w2) (A^2)*(2 + w1*w2) -(A^3)*(w1+w2) A^4];

 xcn(c,:) = filter(b,a,xn);% Now each subband signal is stored in xcn.
end
