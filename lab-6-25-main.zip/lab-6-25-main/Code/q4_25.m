F_notes = 50:5:100;
N = 5;
A = zeros(1,N);
for k = 1:N
    A(k) = 1/k^2;
end
P = zeros(1,N);
fs = 10000;
td_notes = ones(size(F_notes));
adsr = [0.2,0.2,0.7,0.4,0.2];
y = my_synthesizer(A,F_notes,P,adsr,td_notes,fs);
%soundsc(y,fs);

F_notes1 = 100:-10:40;
y1 = my_synthesizer(A,F_notes1,P,adsr,td_notes,fs);
%soundsc(y1,fs);

M = 5;
F_notes2 = 50 + 50*rand(1,M);
td_notes1 = 0.5 + round(rand(1,M),2);
y2 = my_synthesizer(A,F_notes2,P,adsr,td_notes1,fs);
soundsc(y2,fs);



%%

fs = 10000;
adsr = [0.3,0.2,0.7,0.3,0.2];
G = 196;
D = 146.83;
E=	330;
B=	494;
C=	523;

F_notes = [G,D,E,B,C];
td_notes = ones(length(F_notes));
A = ones(length(F_notes));
P = zeros(size(A)); 
xt = my_synthesizer(A,F_notes,P,adsr,td_notes,fs);%generating sound
soundsc(xt,fs);

audiowrite('Audio.wav',xt,fs)




