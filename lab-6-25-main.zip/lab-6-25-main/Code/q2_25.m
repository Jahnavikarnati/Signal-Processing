fs = 10000 ;
N = 5;
f0 = 50;
P = zeros(1,N);
td = 1 ;

A = zeros(1,N);
for k = 1:N
    A(k) = 1/k;
end


xn1 = harmonics(A,f0,P,td,fs);
%soundsc(xn1,fs);

A1 = zeros(1,N);
for k = 1:N
    A1(k) = 1/(k^2);
end
xn2 = harmonics(A1,f0,P,td,fs);
% soundsc(xn2,fs);

A2 = zeros(1,N);
for k = 1:N
    A2(k) = sin(pi*k/N);
end
xn3 = harmonics(A2,f0,P,td,fs);
%soundsc(xn3,fs);

A3 = zeros(1,N);
for k = 1:N
    A3(k) = cos(pi*k/N);
end
xn4 = harmonics(A3,f0,P,td,fs);
%soundsc(xn4,fs);

A4 = zeros(1,N);
for k = 1:N
    A4(k) = k;
end
xn5 = harmonics(A4,f0,P,td,fs);
soundsc(xn5,fs);

y1 = xn1(1:1, 1:500);
y2 = xn2(1:1, 1:500);
y3 = xn3(1:1, 1:500);
y4 = xn4(1:1, 1:500);
y5 = xn5(1:1, 1:500);

subplot(3,2,1);plot(y1);
title('ak = 1/k');
subplot(3,2,2);plot(y2);
title('ak = 1/(k^2)');
subplot(3,2,3);plot(y3);
title('ak = sin(pi*k/N)');
subplot(3,2,4);plot(y4);
title('ak = cos(pi*k/N)');
subplot(3,2,5);plot(y5);
title('ak = k');