function [t_env,env] = envelope(a,d,s,sd,r,fs)
tattack = 0:1/fs:a;
env = tattack/a;
t_env = tattack;

tdecay = a+1/fs  : 1/fs : a+d;
env = [env,((tdecay-a)*(s-1)/(d) +1)];
t_env = [t_env,tdecay];

tsustain = a+d+1/fs: 1/fs : a+d+sd;
t = s*ones(size(tsustain));
env = [env,t];
t_env = [t_env,tsustain];

trelease = a+d+sd+1/fs : 1/fs : a+d+sd+r;
env = [env, -s*(trelease-(a+d+sd+r))/r];
t_env = [t_env,trelease];


end