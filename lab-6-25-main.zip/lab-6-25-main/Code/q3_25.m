fs = 10000;
N = 5;
f0 = 50;
P = zeros(1,N);
td = 1 ;
A = zeros(1,N);
for k = 1:N
    A(k) = 1/k;
end


xn = harmonics(A,f0,P,td,fs);

[t_env,env] = envelope(0.2,0.2,0.7,0.4,0.2,fs);
%soundsc(xn,fs);
soundsc(xn.*env,fs);

t = 0:1/fs:1;
subplot(3,1,1);plot(t,xn);
ylabel('xn');title('for ak = 1/k');
subplot(3,1,2);plot(t,env);
ylabel('env')
subplot(3,1,3);plot(t,xn.*env);
ylabel('xn.*env')