fs = 10000 ;
A = [0.5,0.5] ;
P = [0,0] ; 
F1 = [350,440] ;
td = 4 ;
xn1 = SumOfSines(A,F1,P,td,fs);
%sound(xn1,fs);

F2 = [480,620] ;
td2 = 0.5;
b1 = SumOfSines(A,F2,P,td2,fs);
l = size(b1);
z1 = zeros(l);
xn2 = [b1,z1,b1,z1,b1,z1,b1,z1] ;
%sound(xn2,fs);

F3 = [440,480] ;
td3 = 2;
b2 = SumOfSines(A,F3,P,td3,fs);
l = size(b2);
z2 = zeros(l);
xn3 = [b2,z2,b2,z2,b2,z2,b2,z2] ;
sound(xn3,fs);

y1 = xn1(1:1, 1:500);
y2 = xn2(1:1, 1:500);
y3 = xn3(1:1, 1:500);

subplot(3,1,1); plot(y1);
ylabel('x1[n]');title('2 sinusoids of f=350,440Hz');
subplot(3,1,2); plot(y2);
ylabel('x2[n]');title('Alternate copies of b1,z1');
subplot(3,1,3); plot(y3);
ylabel('x3[n]');title('Alternate copies of b2,z2');

%the sound of signals are familiar and looks like beeps and ringing sounds of phone call
