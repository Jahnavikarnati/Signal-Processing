function xt = harmonics(A,f0,P,td,fs)
n = length(A);
F = zeros(n);
for k =1:n
    F(k) = f0*k;
end
xt = SumOfSines(A,F,P,td,fs);

end

