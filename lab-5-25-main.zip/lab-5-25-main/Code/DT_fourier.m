function X = DT_fourier(x,N0,w)

X = zeros(size(w));
n = size(x,2) ;

for k = 1:n
    X = X + x(k)*exp((-1j)*w*(k - N0));
end

end