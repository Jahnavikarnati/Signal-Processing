w = -10 : 0.01 : 10;
x = (1);
N0 = 1;
X1 = DT_fourier(x,N0,w);

figure(1);
subplot(2,2,1);plot(w,abs(X1));
ylabel('Magnitude');xlabel('w');
subplot(2,2,2);plot(w,angle(X1));
ylabel('Phase');xlabel('w');
subplot(2,2,3);plot(w,real(X1));
ylabel('Real part');xlabel('w');
subplot(2,2,4);plot(w,imag(X1));
ylabel('Imaginary part');xlabel('w');
sgtitle('DTFT Of Unit Impulse signal');


N1 = 4;
X2 = DT_fourier(x,N1,w);
figure(2);
subplot(2,2,1);plot(w,abs(X2));
ylabel('Magnitude');xlabel('w');
subplot(2,2,2);plot(w,angle(X2));
ylabel('Phase');xlabel('w');
subplot(2,2,3);plot(w,real(X2));
ylabel('Real part');xlabel('w');
subplot(2,2,4);plot(w,imag(X2));
ylabel('Imaginary part');xlabel('w');
sgtitle('DTFT Of Shifted Unit Impulse signal');

n = -3:1:3;
x1 = ones(size(n));
N2 = 4;
X3 = DT_fourier(x1,N2,w);
figure(3);
subplot(2,2,1);plot(w,abs(X3));
ylabel('Magnitude');xlabel('w');
subplot(2,2,2);plot(w,angle(X3));
ylabel('Phase');xlabel('w');
subplot(2,2,3);plot(w,real(X3));
ylabel('Real part');xlabel('w');
subplot(2,2,4);plot(w,imag(X3));
ylabel('Imaginary part');xlabel('w');
sgtitle('DTFT Of Rectangular pulse');

N3 = 201;
n = -200:1:200;
x2 = sin(pi*n/4);
X4 = DT_fourier(x2,N2,w);
figure(4);
subplot(2,2,1);plot(w,abs(X4));
ylabel('Magnitude');xlabel('w');
subplot(2,2,2);plot(w,angle(X4));
ylabel('Phase');xlabel('w');
subplot(2,2,3);plot(w,real(X4));
ylabel('Real part');xlabel('w');
subplot(2,2,4);plot(w,imag(X4));
ylabel('Imaginary part');xlabel('w');
sgtitle('DTFT Of Sinusoid');

%%

w = -10 : 0.01 : 10;
n = 0 : 1: 100;

figure(1);
b = 0.01;
a = b;
x1 = a.^n;
a = -b;
x2 = a.^n;
N0 = 1;

X1 = DT_fourier(x1,N0,w);
X2 = DT_fourier(x2,N0,w);
subplot(2,2,1);plot(n,x1);
ylabel('Time domain signal(a=b)');xlabel('n');
subplot(2,2,2);plot(n,x2);
ylabel('Time domain signal(a=-b)');xlabel('n');
subplot(2,2,3);plot(w,abs(X1));
ylabel('Magnitude(a=b)');xlabel('w');
subplot(2,2,4);plot(w,abs(X2));
ylabel('Magnitude(a=-b)');xlabel('w');
sgtitle('For b = 0.01');


figure(2);

b = 0.5;
a = b;
x1 = a.^n;
a = -b;
x2 = a.^n;
N0 = 1;

X1 = DT_fourier(x1,N0,w);
X2 = DT_fourier(x2,N0,w);
subplot(2,2,1);plot(n,x1);
ylabel('Time domain signal(a=b)');xlabel('n');
subplot(2,2,2);plot(n,x2);
ylabel('Time domain signal(a=-b)');xlabel('n');
subplot(2,2,3);plot(w,abs(X1));
ylabel('Magnitude(a=b)');xlabel('w');
subplot(2,2,4);plot(w,abs(X2));
ylabel('Magnitude(a=-b)');xlabel('w');
sgtitle('For b = 0.5');

figure(3);

b = 0.99;
a = b;
x1 = a.^n;
a = -b;
x2 = a.^n;
N0 = 1;

X1 = DT_fourier(x1,N0,w);
X2 = DT_fourier(x2,N0,w);
subplot(2,2,1);plot(n,x1);
ylabel('Time domain signal(a=b)');xlabel('n');
subplot(2,2,2);plot(n,x2);
ylabel('Time domain signal(a=-b)');xlabel('n');
subplot(2,2,3);plot(w,abs(X1));
ylabel('Magnitude(a=b)');xlabel('w');
subplot(2,2,4);plot(w,abs(X2));
ylabel('Magnitude(a=-b)');xlabel('w');
sgtitle('For b = 0.99');

% From the plots we can tell when a=b the filter acts as a low pass filter and when a=-b it acts as a high pass filter.
% We could observe that as the value of b increases the X(w) signal gets narrower.
