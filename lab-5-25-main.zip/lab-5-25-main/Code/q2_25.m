n = 0:1:1000;
w0 = pi/200;
w = -10:0.01:10;
N0 = 1;
sn = 5*sin(w0*n);
vn = randn(1,1001);
xn = sn + vn;

figure(1);
subplot(2,2,1);plot(n,sn,'-r');
hold on;
plot(n,xn,'-b')
legend('s[n]','x[n]');title('s[n] and x[n]'); 

X1 = DT_fourier(xn,N0,w);
X2 = DT_fourier(sn,N0,w);
figure(2);
subplot(2,2,1);plot(w,abs(X1),'-r')
hold on
plot(w,abs(X2),'-b')
legend('|X(w)|','|S(w)|');title('DTFT of x[n],s[n]');

M = 5;
hn = ones(1,M);
for k = 0:M-1
    hn(k+1) = 1/M;
    
end
yn = conv((xn),(hn),'full');
figure(1);
subplot(2,2,2);plot(yn,'-r')
hold on
plot(n,sn,'-b');
legend('y[n]','s[n]');title('y[n] and s[n] for M=5');

X1 = DT_fourier(xn,N0,w);
X2 = DT_fourier(yn,N0,w);
figure(2);
subplot(2,2,2);plot(w,abs(X1),'-r')
hold on
plot(w,abs(X2),'-b')
legend('|X(w)|','|Y(w)|');title('DTFT of y[n],x[n] M = 5');



M = 21;
hn = ones(1,M);
for k = 0:M-1
    hn(k+1) = 1/M;
    
end
yn = conv((xn),(hn),'full');
figure(1);
subplot(2,2,3);plot(yn,'-r')
hold on
plot(sn,'-b')
legend('y[n]','s[n]');title('y[n] and s[n] for M=21');

X1 = DT_fourier(xn,N0,w);
X2 = DT_fourier(yn,N0,w);
figure(2);
subplot(2,2,3);plot(w,abs(X1),'-r')
hold on
plot(w,abs(X2),'-b')
legend('|X(w)|','|Y(w)|');title('DTFT of y[n],x[n] M = 21');

M = 51;
hn = ones(1,M);

for k = 0:M-1
    hn(k+1) = 1/M;
end
yn = conv((xn),(hn),'full');
figure(1);
subplot(2,2,4);plot(yn,'-r')
hold on
plot(sn,'-b')
legend('y[n]','s[n]');title('y[n] and s[n] for M=51');
sgtitle('For Moving average filter');

X1 = DT_fourier(xn,N0,w);
X2 = DT_fourier(yn,N0,w);
figure(2);
subplot(2,2,4);plot(w,abs(X1),'-r')
hold on
plot(w,abs(X2),'-b');
legend('|X(w)|','|Y(w)|');title('DTFT of y[n],x[n] M = 51');
sgtitle('For Moving average filter'); 

% a. impulse response for the above LTI system is 1/M for all n belongs to [0,M-1] and 0 otherwise.
% e. From the plot we can tell that as M is increasing the output signal becomes more clearer and we observe deviation from the noisy signal. The clarity of the output signal
% is trade off with deviation from the input signal.
% f. We can observe from the plot that the moving average filter is a low pass filter.

%%
n = 0:1:1000;
w0 = pi/200;
w = -10:0.01:10;
N0 = 1;
sn = 5*sin(w0*n);
vn = randn(1,1001);
xn = sn + vn;


subplot(2,2,1);plot(n,sn,'-r');
hold on;
plot(n,xn,'-b')
legend('s[n]','x[n]');title('s[n] and x[n]');

hn = zeros(1,M);
hn(1) = 1;
hn(2) = -1;
yn = conv((xn),(hn),'full');
subplot(2,2,2);plot(sn,'-r')
hold on
plot(yn,'-b')
legend('s[n]','y[n]');title('y[n] and s[n]');

X1 = DT_fourier(xn,N0,w);
X2 = DT_fourier(yn,N0,w);

subplot(2,2,3);plot(w,abs(X1),'-r')
hold on
plot(w,abs(X2),'-b')
legend('|X(w)|','|Y(w)|');title('DTFT of y[n],x[n]');
sgtitle('For Digital Differentiator');

% g. From the plot we can tell that the digital differentiator is a high pass filter.

