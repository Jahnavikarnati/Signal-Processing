% Computing DFT of rectangular window with different values of N.
N = [4,16,64];
L = 4;
for k = 1:3
    x = [ones(L,1);zeros(N(k)-L,1)];
    t = 0:1:N(k)-1;
    n = 2*pi*t/N(k);
    xn = fft(x,N(k));
    figure(k);
    subplot(3,1,1);stem(n,xn);
    title('sequence of the DFT');
    xlabel('Frequency');
    subplot(3,1,2);stem(n,abs(xn));
     title('Magnitude of the DFT');
     xlabel('Frequency');
    subplot(3,1,3);stem(n,angle(xn));
     title('phase of the DFT');
     xlabel('Frequency');
     sgtitle(sprintf('For N = %d',4^k));
end

% Computing DFT of sin(𝜔0𝑛), for 𝜔0 = 3𝜋/10 and N = 20
figure(4);
w0 = 3*pi/10;
N =20;
t = 0:1:N-1;
n1 = 2*pi*t/N;
xn1 = sin(w0*n1);
Xk1 = fft(xn1,N);

subplot(3,1,1);stem(n1,Xk1);
title('sequence of the DFT');
xlabel('Frequency');
subplot(3,1,2);stem(n1,abs(Xk1));
title('Magnitude of the DFT');
xlabel('Frequency');
subplot(3,1,3);stem(n1,angle(Xk1));
title('phase of the DFT');
xlabel('Frequency');
sgtitle('DFT of sin(𝜔0𝑛), for 𝜔0 = 3𝜋/10 and N = 20');

% Computing DFT of cos(𝜔0𝑛), for 𝜔0 = 3𝜋/10 and N = 20
figure(5);
xn2 = cos(w0*t);
Xk2 = fft(xn2,N);

subplot(3,1,1);stem(n1,Xk2);
title('sequence of the DFT');
xlabel('Frequency');
subplot(3,1,2);stem(n1,abs(Xk2));
title('Magnitude of the DFT');
xlabel('Frequency');
subplot(3,1,3);stem(n1,angle(Xk2));
title('phase of the DFT');
xlabel('Frequency');
sgtitle('DFT of cos(𝜔0𝑛), for 𝜔0 = 3𝜋/10 and N = 20');

% Computing DFT of  sin(𝜔0(𝑛 − 1)), 𝜔0 = 3𝜋/10 and N = 20
figure(6);
xn3 = sin(w0*(t-1));
Xk3 = fft(xn3,N);
subplot(3,1,1);stem(n1,Xk3);
title('sequence of the DFT');
xlabel('Frequency');

subplot(3,1,2);stem(n1,abs(Xk3));
title('Magnitude of the DFT');
xlabel('Frequency');
subplot(3,1,3);stem(n1,angle(Xk3));
title('phase of the DFT');
xlabel('Frequency');
sgtitle('DFT of sin(𝜔0(n-1)), for 𝜔0 = 3𝜋/10 and N = 20');

% Computing DFT of (0.8)^n for N = 20
figure(7);
xn4 = (0.8).^t;
Xk4 = fft(xn4,N);

subplot(3,1,1);stem(n1,Xk4);
title('sequence of the DFT');
xlabel('Frequency');
subplot(3,1,2);stem(n1,abs(Xk4));
title('Magnitude of the DFT');
xlabel('Frequency');
subplot(3,1,3);stem(n1,angle(Xk4));
title('phase of the DFT');
xlabel('Frequency');
sgtitle('DFT of (0.8)^n for N = 20');

% Computing DFT of (-0.8)^n for N = 20
figure(8);
xn5 = (-0.8).^t;
Xk5 = fft(xn5,N);

subplot(3,1,1);stem(n1,Xk5);
title('sequence of the DFT');
xlabel('Frequency');
subplot(3,1,2);stem(n1,abs(Xk5));
title('Magnitude of the DFT');
xlabel('Frequency');
subplot(3,1,3);stem(n1,angle(Xk5));
title('phase of the DFT');
xlabel('Frequency');
sgtitle('DFT of (-0.8)^n for N = 20');

% Yes, we can indentify the high,low frequencies from the spectrum.