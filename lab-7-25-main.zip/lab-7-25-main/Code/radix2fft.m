% % radix2fft function to compute the DFT of a signal x

function X = radix2fft(x)                                            
N = length(x); % size of x                                                                
k = N/2;
                                                                   
for m = 1:log2(N)                                                             
    for index = 0:(N/(2^(m-1))):(N-1) % Computing butterflies at each m                                   
        for n = 0:(k-1)                                                   
            count = n+index+1;                                                  
            q = (2^(m-1))*n;                                           
            a = x(count)+x(count+k);      % 1st part of the butterfly operation                                      
            b = (x(count)-x(count+k)).*exp((-1i)*(2*pi)*q/N);  % 2nd part of the butterfly operation                                     
            x(count) = a;    % saving the results in x                                                  
            x(count+k)= b;                                      
        end
    end
k=k/2;                                                                
end

X = bitrevorder(x);    %returning the function by doing bit reversal

end
% Yes, The output of our function matches with that of fft within numerical
% precision.
