% Fourier transform P(w) of p(t) is pi*(delta(w-w0)+delta(w+w0))
% DTFT for p[n] is pi*(delta(w-w0)+delta(w+w0)) for w = [-pi,pi]
% The graph of DTFT for p[n] is periodic with period 2*pi.
% We can tell that the fourier transform of x[n] will be equal to (fourier transform of p[n])*L = (P(e^jw))*L (from the multiplication property).

f0= 12;  %fundamental frequency of the p(t) signal
fs = 64; %Frequency at which p(t) signal is being sampled.
L =16;

pn =zeros(1,L);
xn =zeros(1,L);

% Computing the values of p[n] and x[n] where x[n]=p[n]*w[n]
% w[n] is 1 for n=0 to L-1
for k = 1:L
    pn(k) = cos(2*pi*f0*(k-1)/fs);
    xn(k) = pn(k);
end

figure(1);
m = 1;
N = m*L; 
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);    % Calculating the DFT of the signal x[n] when m=1
 % Plotting the magnitude spectrum of the calculated DFT
subplot(2,2,1);stem(n,abs(Xk1)); 
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=1');
sgtitle('f0=12Hz');

 % Calculating the DFT of the signal x[n] when m=2
m = 2;
N = m*L;
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);
subplot(2,2,2);stem(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=2');

% Calculating the DFT of the signal x[n] when m=4
m = 4;
N = m*L;
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);
subplot(2,2,3);plot(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=4');

% Calculating the DFT of the signal x[n] when m=8
m = 8;
N = m*L;
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);
subplot(2,2,4);plot(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=8');

figure(2);
% Before we computed DFT by varying N now we will be changing the value's of L
L = [16,32,64,128];

for k =1:4
    pn = zeros(1,L(k));
    xn = zeros(1,L(k));
    for n = 1:L(k)
        pn(n) = cos(2*pi*f0*(n-1)/fs);
        xn(n) = pn(n);
    end
    m = 8;
    N = m*L(k);
    t = 0:1:N-1;
    n = 2*pi*t/N;
    XK = fft(xn,N);
    subplot(2,2,k);plot(n,abs(XK));
    xlabel('Frequency');ylabel('Magnitude');
    title(sprintf('For L = %d',16*k));
   
end

figure(3);
%Now we will be calculating the DFT when f0=11.
f0= 11;
fs = 64;
L =16;

pn =zeros(1,L);
xn =zeros(1,L);

for k = 1:L
    pn(k) = cos(2*pi*f0*(k-1)/fs);
    xn(k) = pn(k);
end

% Calculating the DFT of the signal x[n] when m=1
m = 1;
N = m*L;
Xk1 = fft(xn,N);
t = 0:1:N-1;
n = 2*pi*t/N;
sgtitle('f0=11Hz');
subplot(2,2,1);stem(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=1');

% Calculating the DFT of the signal x[n] when m=2
m = 2;
N = m*L;
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);
subplot(2,2,2);stem(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=2');

% Calculating the DFT of the signal x[n] when m=4
m = 4;
N = m*L;
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);
subplot(2,2,3);plot(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=4');

% Calculating the DFT of the signal x[n] when m=8
m = 8;
N = m*L;
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);
subplot(2,2,4);plot(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=8');

figure(4);
%Now we will be calculating the DFT when w[n] is a hanning window.
f0= 12;
fs = 64;
L =16;

pn =zeros(1,L);
wn = hann(L);
xn =zeros(1,L);

for k = 1:L
    pn(k) = cos(2*pi*f0*(k-1)/fs);
    xn(k) = wn(k)*pn(k);
end

% Calculating the DFT of the signal x[n] when m=1
m = 1;
N = m*L;
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);
sgtitle('𝑤[𝑛] is an L-length Hanning window');
subplot(2,2,1);stem(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=1');

% Calculating the DFT of the signal x[n] when m=2
m = 2;
N = m*L;
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);
subplot(2,2,2);stem(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=2');

% Calculating the DFT of the signal x[n] when m=4
m = 4;
N = m*L;
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);
subplot(2,2,3);plot(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=4');

% Calculating the DFT of the signal x[n] when m=8
m = 8;
N = m*L;
t = 0:1:N-1;
n = 2*pi*t/N;
Xk1 = fft(xn,N);
subplot(2,2,4);plot(n,abs(Xk1));
xlabel('Frequency');ylabel('Magnitude');
title('L=16,m=8');


%%
% i part
% We need to estimate the value of f0 from fs and magnitude spectrum of DFT
% We know that peaks occur at 2*pi*f0/fs and (2*pi - 2*pi*f0/fs), suppose
% lets say they occur at w1,w2.
% From the above we can tell that (w2-w1) = (2*pi - 4*pi*f0/fs)
% As we know the value of fs and by computing the values of w2,w1 from the
% Magnitude spectrum of DFT we can get the value of f0.
% Lets see how the code look's like

% Take a DFT signal say Xk then

[pks,loc] = max(Xk);
w1 = (loc-1)*2*pi/N;
w2 = 2*pi - w1;

%then f0 is given by
f0 = ((0.5-(abs(w2 -w1)/(4*pi) )))*fs ;
disp(f0)
% We could implement this succesfully in e,g,h if we observe those values
% as N is increasing we will get f0 accurately.
%%
%j part
[y,fs] = audioread('audio files_01.wav');
pn = y(:,1);
L = power(2,16);
m = 16;
N = m*L;
k = length(pn);
xn = pn(1:L);

Xk1 = fft(xn,N);
[pks,loc] = maxk(Xk1,3);
w1 = (loc-1)*2*pi/N;
w2 = 2*pi - w1;
 f0 = ((0.5-(abs(w2 -w1)/(4*pi) )))*fs ;
disp(f0)
% In the command window we could see the three strong frequencies.
