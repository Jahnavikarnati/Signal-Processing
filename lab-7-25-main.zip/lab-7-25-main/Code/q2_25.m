% We will be generating a random gaussian sequence xn1.
xn1 = random('norm',0,1,1,10);
% And 𝑥𝑛2  first 10 samples of the signal 𝛿[𝑛 − 3] starting from n = 0.
xn2 = zeros(1,10);
xn2(4) = 1;
N1 = 0:1:9;
N2 = 0:1:18;
X1 = cconv(xn1,xn2,10); %Circular convolution of xn1 and xn2 using cconv command.
X2 = conv(xn1,xn2);     %Linearar convolution of xn1 and xn2 using conv command.

subplot(2,2,1);stem(N1,X1);
title('circular conv using cconv');
subplot(2,2,2);stem(N2,X2);
title('linear conv using conv');

N = 10;
%Circular convolution of xn1 and xn2 using DFT and inverse DFT of xn1 and xn2
Xk1 = fft(xn1,N);
Xk2 = fft(xn2,N);
Xk = Xk1.*Xk2;
x1 = ifft(Xk);

n = 19;
% Computing the linear convolution of xn1 and xn2 using DFT properties and zero padding.
A = zeros(1,9);
xn_1 = [xn1,A];
xn_2 = [xn2,A];
Xk_1 = fft(xn_1,n);
Xk_2 = fft(xn_2,n);
Xkl = Xk_1.*Xk_2;
x2 = ifft(Xkl);
subplot(2,2,3);stem(N1,x1);
title('circular conv using DFT method');
subplot(2,2,4);stem(N2,x2);
title('linear conv using DFT method');
sgtitle('linear and circular convolutions of 𝑥1[𝑛] and 𝑥2[𝑛]');

