syms w
N=51;
hdn=zeros(1,N);
nc = (N-1)/2;
% computing the valiue hd[n] for N values
for k=1:51
expr= exp(1j*w*(k-1-nc));
hdn(k)=(1/(2*pi))* int(expr,-1*pi/6,pi/6);
end

wn=rectwin(N);%rectwin generates a rectangular window of length N
w = wn';
hn = hdn.*w; % creating a causal linear-phase FIR filter
n = 0:1:50;
subplot(2,2,1);plot(n,hn);
xlabel('n'); ylabel('h[n]');
title('Plot for h[n]');

H = fft(hn,1001);%determining the DFT of h[n]
k = max(abs(H));% normalizing and plotting the DFT magnitude in decibel scale
t = 0:1:1000;
w = 2*pi*t/1001;
subplot(2,2,2);plot(w,20*log10(abs(H)/k));
ylim([-100 10]);
xlabel('w');ylabel('Magnitude(db)');
subplot(2,2,3);plot(w,angle(H));
xlabel('w'); ylabel('phase');

%%
%partc
syms w
N=51;
hdn=zeros(1,N);
nc = (N-1)/2;
% computing the valiue hd[n]
for k=1:51
expr= exp(1j*w*(k-1-nc));
hdn(k)=(1/(2*pi))* int(expr,-1*pi/6,pi/6);
end

wn=blackman(N);%rectwin generates a rectangular window of length N
w = wn';
hn = hdn.*w; % creating a causal linear-phase FIR filter
n = 0:1:50;
subplot(2,2,1);plot(n,hn);
xlabel('n'); ylabel('h[n]');
title('Plot for h[n]');

H = fft(hn,1001);%determining the DFT of h[n]
k = max(abs(H));% normalizing and plotting the DFT magnitude in decibel scale
t = 0:1:1000;
w = 2*pi*t/1001;
subplot(2,2,2);plot(w,20*log10(abs(H)/k));
ylim([-100 10]);
xlabel('w');ylabel('Magnitude(db)');
subplot(2,2,3);plot(w,angle(H));
xlabel('w'); ylabel('phase');

%%
%part-e
n = 0:1:200;
xn = cos(n*pi/16)+ 0.25*sin(n*pi/2);
% we will be computing the signal after x[n] is passed through the above
% generated filters.
syms w
N=51;
hdn=zeros(1,N);
nc= (N-1)/2;

for k=1:51
expr= exp(1j*w*(k-1-nc));
hdn(k)=(1/(2*pi))* int(expr,-1*pi/6,pi/6);
end

wn=rectwin(N);
w = wn';
hn1 = hdn.*w;

y1 = conv(xn,hn1);

wn=blackman(N);
w = wn';
hn2 = hdn.*w;

y2 = conv(xn,hn2);

figure(1);
subplot(2,2,1);plot(n,xn);
xlabel('n');ylabel('x[n]');
title('Orginal signal x[n]');
subplot(2,2,2);plot(y1);
xlabel('n');
title('Filtered signal(rect window)');
subplot(2,2,3);plot(y2);
xlabel('n');
title('Filtered signal(blackman window)');

x1n = cos(n*pi/16) + 0.25*randn(1,201);
Y1 = conv(x1n,hn2);
Y2 = conv(x1n,hn2);

figure(2);
subplot(2,2,1);plot(n,x1n);
title('Orginal signal x1[n]');
subplot(2,2,2);plot(y1);
xlabel('n');
title('Filtered signal(rect window)');
subplot(2,2,3);plot(y2);
xlabel('n');
title('Filtered signal(blackman window)');

%%
%partf


syms w
N=51;
hdn=zeros(1,N);
nc= (N-1)/2;

for k=1:51
expr= exp(1j*w*(k-1-nc));
hdn(k)=(1/(2*pi))* int(expr,-1*pi/6,pi/6);
end

wn=rectwin(N);
w = wn';
hn = hdn.*w;

h1n = zeros(1,51);
for n=0:50
h1n(n+1) = ((-1)^n)*hn(n+1);
end

n = 0:1:50;
subplot(2,2,1);plot(n,h1n);
xlabel('n'); ylabel('h[n]');
title('Plot for h[n]');

H = fft(h1n,1001);
k = max(abs(H));
t = 0:1:1000;
w = 2*pi*t/1001;
subplot(2,2,2);plot(w,20*log10(abs(H)/k));
ylim([-100 10]);
xlabel('w');ylabel('Magnitude(db)');
subplot(2,2,3);plot(w,angle(H));
xlabel('w'); ylabel('phase');

%d rectangular window has less transition width and high ripples in side band whereas blackman window has comparitively higher 
%transition width and lower ripples in side band
%f dtft of h1[n] is shifted by pi towards right of dtft of  h[n] thus generic LPF becomes a HPF
