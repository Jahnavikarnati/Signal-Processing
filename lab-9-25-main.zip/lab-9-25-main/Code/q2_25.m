N = 2001;
w = pi/4;
k = 1+cos(w);
b = [k, k*-2*cos(w), k];
a = [1 0 0];

freqz(b,a,N);%2001 frequency response of the filter
fvtool(b,a);
%%
N = 2001;
w = pi/4;
r = 0.9;
k = (r^2 + 1 - 2*r*cos(w))*(1+cos(w));
b = [k, k*-2*cos(w), k];
a = [1, -2*r*cos(w), r^2];

freqz(b,a,N);
fvtool(b,a)
%%
%part d

w = pi/4;
r = 0.5;
k = (r^2 + 1 - 2*r*cos(w))*(1+cos(w));
b = [k, k*-2*cos(w), k];
a = [1, -2*r*cos(w), r^2];
fvtool(b,a)

r = 0.99;
k = (r^2 + 1 - 2*r*cos(w))*(1+cos(w));
b = [k, k*-2*cos(w), k];
a = [1, -2*r*cos(w), r^2];

fvtool(b,a)
%%
%part -e

fs = 8192;
xn = rand(1,2*fs)-0.5;
X = xn';
%sound(X);
f0 = 1024;
k = 0:1/fs:2-(1/fs);
x1n = sin(2*pi*f0*k);
yn = xn + x1n;
%sound(yn)

w = pi/4;
k = 1+cos(w);
b1 = [k, k*-2*cos(w), k];
a1 = [1 0 0];
r = 0.9;
k = (r^2 + 1 - 2*r*cos(w))*(1+cos(w));
b2 = [k, k*-2*cos(w), k];
a2 = [1, -2*r*cos(w), r^2];
Y1 = filter(b1,a1,yn);
%sound(Y1);
Y2 = filter(b2,a2,yn);
%sound(Y2);

subplot(2,2,1);plot(xn);
xlim([0 99]);xlabel('n');ylabel('x[n]');
subplot(2,2,2);plot(yn);
xlim([0 99]);xlabel('n');title('x[n]+sin(2*pi*f0*n/fs)');
subplot(2,2,3);plot(abs(Y1));
xlim([0 99]);xlabel('n');title('Filtering the signal with the FIR filter');
subplot(2,2,4);plot(abs(Y2));
xlim([0 99]);xlabel('n');title('Filtering the signal with the IIR filter');

% FIR filter given is stable and causal since the unit circle is lying in roc and roc is |z|>0
% IIR filter given  may be stable or not , it depends on ROC since there are two possible roc's for this,similiarly for causality
