Nquist_rate = 5*pi/pi;
disp(Nquist_rate)
t_fine =  0: 0.001 :2;
Ts = 0.1;
t_samples = 0: Ts :2;
n =length(t_samples) ;
xn = cos(5*pi*t_samples);
xr = sinc_recon(n,xn,Ts,t_fine,t_samples);
subplot(2,2,1);
plot(t_fine,xr,'-b');
hold on 
stem(t_samples,xn,'-r');
xlabel('time(s)');
title('For Ts=0.1');
legend('Reconstructed signal','samples');
hold off;
grid minor

Ts = 0.2;
t_samples = 0: Ts :2;
n = length(t_samples);
xn = cos(5*pi*t_samples);
xr = sinc_recon(n,xn,Ts,t_fine,t_samples);
subplot(2,2,2);
plot(t_fine,xr,'-b');
hold on 
stem(t_samples,xn,'-r');
xlabel('time(s)');
title('For Ts=0.2');
hold off;
grid minor

Ts = 0.3;
t_samples = 0: Ts :2;
n = length(t_samples);
xn = cos(5*pi*t_samples);
xr = sinc_recon(n,xn,Ts,t_fine,t_samples);
subplot(2,2,3);
plot(t_fine,xr,'-b');
hold on 
stem(t_samples,xn,'-r');
xlabel('time(s)');
hold off;
title('For Ts=0.3');
grid minor

Ts = 0.4;
t_samples = 0: Ts :2;
n = length(t_samples);
xn = cos(5*pi*t_samples);
xr = sinc_recon(n,xn,Ts,t_fine,t_samples);
subplot(2,2,4);
plot(t_fine,xr,'-b');
hold on 
stem(t_samples,xn,'-r');
xlabel('time(s)');
hold off;
title('For Ts=0.4');
grid minor


% From the graphs we can say that as the sampling time interval is
% increasing the reconstructed graph is deviating more from the orginal
% graph. We could support our observations theoretically also as the value
% of Ts is incresing ws value will decrease. For Ts=0.3,0.4 ws will be less
% than 2*wm, so we can say that we won't be getting the exact orginal
% signal.
