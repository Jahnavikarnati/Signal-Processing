%3.1

t_fine = 0: 0.001 :2; %time-grid for representing continuous time-signals
Ts = 0.1; % sampling interval 
t_samples = 0: Ts :2;

xt = cos(5*pi*t_fine) + sin(10*pi*t_fine); % continous time signal
% plotting x(t) Vs time
subplot(2,1,1);plot(t_fine,xt); 
xlabel('time(s)'); ylabel('x(t)');
title('plot for x(t)')
% plotting the samples
xn = cos(5*pi*t_samples) + sin(10*pi*t_samples);
subplot(2,1,2);stem(t_samples,xn);
xlabel('time(s)'); ylabel('x[n]');
title('plot for x[n]');



