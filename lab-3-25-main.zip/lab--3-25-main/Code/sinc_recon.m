function xr = sinc_recon(n,xn,Ts,t_fine,t_samples)
wc = pi/Ts;
xr = zeros(size(t_fine));
for k = 1:n
 xr = xr + Ts.*xn(k).*sinc((wc*(t_fine-t_samples(1)-(k-1)*Ts))/pi).*wc/pi;
 
end

end

% This a function that is used to reconstruct the orginal signal from it samples using sinc interpolation.
