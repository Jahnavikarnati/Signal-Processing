%3.2a

t_fine = 0: 0.001 :2;
Ts = 0.1;
t_samples = 0: Ts :2;

% plotting the xt signal.
xt = cos(5*pi*t_fine) + sin(10*pi*t_fine);
subplot(2,2,1);plot(t_fine,xt); 
xlabel('time(s)'); ylabel('x(t)');
yt = cos(5*pi*t_samples) + sin(10*pi*t_samples);
title('xt');

% plotting the reconstructed signal based on zero order hold interpolation.
yi = interp1(t_samples,yt,t_fine,'previous'); 
subplot(2,2,2);plot(t_fine,yi,'-r')
hold on
plot(t_fine,xt,'-b');
hold off
xlabel('time(s)'); ylabel('signal');
title('Zero order hold reconstruction of 𝑥(𝑡)');
legend('reconstructed signal','orginal signal');
grid minor;

t = 0.25:0.001:1.75;
xt1 = cos(5*pi*t) + sin(10*pi*t);
yi1 = interp1(t_samples,yt,t,'previous'); 
% finding maximum absolute error.
MAE = max(abs(yi1-xt1));
disp(MAE);

% plotting the reconstructed signal based on linear interpolation.
yi = interp1(t_samples,yt,t_fine); 
subplot(2,2,3);plot(t_fine,yi,'-r')
hold on
plot(t_fine,xt,'-b');
hold off
xlabel('time(s)'); ylabel('signal');
title('Linear interpolation based signal reconstruction of 𝑥(𝑡)');
grid minor;

t = 0.25:0.001:1.75;
xt1 = cos(5*pi*t) + sin(10*pi*t);
yi1 = interp1(t_samples,yt,t); 
% finding maximum absolute error.
MAE = max(abs(yi1-xt1));
disp(MAE);

% plotting the reconstructed signal based on sinc interpolation.
n = 20;
xt = cos(5*pi*t_fine) + sin(10*pi*t_fine);
xn = cos(5*pi*t_samples) + sin(10*pi*t_samples);
xr = sinc_recon(n,xn,Ts,t_fine,t_samples);
subplot(2,2,4);plot(t_fine,xr,'-r');
hold on
plot(t_fine,xt,'-b');
hold off
xlabel('time(s)'); ylabel('signal');
title('sinc interpolation');
grid minor

t = 0.25:0.001:1.75;
Ts=0.1;
t_samples = 0: Ts :2;
n=length(t_samples);
xt1 = cos(5*pi*t) + sin(10*pi*t);

xn = cos(5*pi*t_samples) + sin(10*pi*t_samples);
xr = sinc_recon(n,xn,Ts,t,t_samples);
% finding maximum absolute error.
MAE = max(abs(xr-xt1));
disp(MAE);
% From the plot of the sinc interpolation and comparing it with other method interpolation we can say that the reconstructed signal is more similar to the orginal case in case of sinc interpolation 
% As sinc interpolation is a ideal reconstruction we can say that in case of sinc interpolation we get the reconstructed signal same as the orginal signal. In this case as we
% restrict each of the sinc in the summation to the interval [0, 2] we can say that we don't get the exact same as the orginal signal.
% We could also observe this by calculating the maximun absolute error in each case and we can find out that it is the least in case odf sinc interpolation then for linear
%interpolation then zero order hold. We could also say this from observing the graphs also.
%%
%optional
% reconstructing the signal based on next interpolation method.
t_fine = 0: 0.001 :2;
Ts = 0.1;
t_samples = 0: Ts :2;
yi = interp1(t_samples,yt,t_fine,'next'); 
plot(t_fine,yi,'-r')
hold on
plot(t_fine,xt,'-b');
hold off
xlabel('time(s)'); ylabel('signal');
title('Next interpolation based signal reconstruction of 𝑥(𝑡)');
legend('reconstructed signal','orginal signal');
grid minor;

t = 0.25:0.001:1.75;
xt1 = cos(5*pi*t) + sin(10*pi*t);
yi1 = interp1(t_samples,yt,t,'next'); 
MAE = max(abs(yi1-xt1));
disp(MAE);

