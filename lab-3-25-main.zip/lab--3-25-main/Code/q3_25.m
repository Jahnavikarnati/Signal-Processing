t_fine = -10:0.001:10;
Ts = 0.5;
t_samples = -1:Ts:1 ;
n = length(t_samples);
xn = 1-abs(t_samples);
xr = sinc_recon(n,xn,Ts,t_fine,t_samples); 
subplot(2,2,1); plot(t_fine,xr,'-r');
hold on 
stem(t_samples,xn,'-b');
hold off
xlabel('time(s)'); ylabel('signal');
title('For Ts=0.5');
grid minor;


Ts = 0.2;
t_samples = -1:Ts:1 ;
n = length(t_samples);
xn = 1-abs(t_samples);
xr = sinc_recon(n,xn,Ts,t_fine,t_samples); 
subplot(2,2,2); plot(t_fine,xr,'-r');
hold on 
stem(t_samples,xn,'-b');
hold off
xlabel('time(s)'); ylabel('signal');
title('For Ts=0.2');
grid minor;


Ts = 0.1;
t_samples = -1:Ts:1 ;
n = length(t_samples);
xn = 1-abs(t_samples);
xr = sinc_recon(n,xn,Ts,t_fine,t_samples); 
subplot(2,2,3); plot(t_fine,xr,'-r');
hold on 
stem(t_samples,xn,'-b');
hold off
xlabel('time(s)'); ylabel('signal');
title('For Ts=0.1');
grid minor;



Ts = 0.05;
t_samples = -1:Ts:1 ;
n = length(t_samples);
xn = 1-abs(t_samples);
xr = sinc_recon(n,xn,Ts,t_fine,t_samples); 
subplot(2,2,4); plot(t_fine,xr,'-r');
hold on 
stem(t_samples,xn,'-b');
hold off
xlabel('time(s)'); ylabel('signal');
legend('reconstructed signal','sampled signal'); 
title('For Ts=0.05');
grid minor;

%While we decrease Ts i.e increasing sampling frequency our reconstructed signal will approach the original signal
%since the fourier transform for the original signal is sinc^2(w/2) we are covering more w's of original signal by decreasing Ts 
%and the signal is tending to bandwidth signal.(since higher w's of sinc^2 function goes to 0).






