a = 1;
B = 3;
[x,fs] = audioread('file_example_WAV_1MG.wav');
x1 = x(:,1);
x2 = (x1)';
y = quadratic_quant(x2,B,a);
sound(y,fs);

%%
a = 1;

[x,fs] = audioread('file_example_WAV_1MG.wav');
x1 = x(:,1);
x2 = (x1)';
for B=1:8
y = quadratic_quant(x2,B,a);
k = (length(y)/fs)+2;
sound(y,fs);
pause(k);
end

% By listening to the quantized signal we can observe that there is lot of disturbance in the audio signal as B value is very small we can say that the quality of the audio 
% is very less. As we increase the B(number of bits per sample) we can observe that the quality of the audio is also increasing.
% B plays a role in the quality if the audio. BY quantization affect  we don't observe higher frequency content will be decreased of the quantized signal 
% compared to  that of the input signal.
