f = 10;
a = 1;
B = 4;
fs = 5000;
Ts = (1/fs);
t = 0:Ts:1;

x = sin(2*pi*f*t);
y = quadratic_quant(x,B,a);

eq = x - y;


subplot(3,1,1);plot(t,x,'-b');
xlabel('time(s)');ylabel('x[n]');
title('Sampled signal');

subplot(3,1,2);plot(t,y,'-r');
xlabel('time(s)');ylabel('xq[n]');
title('Quantised signal');

subplot(3,1,3);plot(t,eq,'-b');
xlabel('time(s)');ylabel('e_q');
title('Quantization error');

%%
%d
f = 10;
a = 1;
B = 4;
fs = 5000;
Ts = (1/fs);
t = 0:Ts:1;

x = sin(2*pi*f*t);
y = quadratic_quant(x,B,a);

eq = x - y;
histogram(eq,15);
title('Histogram graph');

%%
%e

f = 10;
a = 1;
fs = 5000;
Ts = (1/fs);
t = 0:Ts:1;
eq = zeros(8);
k = 1:1:8;
x = sin(2*pi*f*t);
for B = 1:8
y = quadratic_quant(x,B,a);
eq(B) = max(abs(x - y));
end

stem(k,eq);
xlabel('B'); ylabel('e_q');
title('maximum absolute quantization error');

% As we are increasing the number of bits for quantization eventually increases the accuracy of time samples that means we can say that the quantization error decreases.
%%
%f
f = 10;
a = 1;
fs = 5000;
Ts = (1/fs);
t = 0:Ts:1;
x = sin(2*pi*f*t);
n = length(x);
eq = zeros(n);
t = 1:1:8;

sum1=0;
sum2 = 0;
sqnr = zeros(8);

for B = 1:8
    y = quadratic_quant(x,B,a);
    for k = 1:n
    sum1 = sum1 + x(k)^2;
    eq(k) = x(k) - y(k);
     sum2 = sum2 + eq(k)^2;
     sqnr(B) = sum1/sum2;
    end
   
end

stem(t,sqnr);
xlabel('B');ylabel('SQNR');
title('Plot for SQNR');

% As we are increasing the number of bits for quantization eventually increases the accuracy of time samples that means we can say that the quantization error decreases.
% So we can say that  SQNR which is defined as the ratio of signal power to quantization noise power, will increase and we will observe the same in the plot.
% Uniform quantisation has equally spaced quantisation levels throughout the range of quantisation where as non -uniform quantisation given in this problem 
%has closely spaced quantisation levels at lower amplitudes of signal and higher spaced levels at higher amplitudes compared to uniform quantisation levels
%thus the non-uniform quantisation gives less error for lower amplitude signals and more error for relatively higher amplitude signals when compared with uniform-quantisation.



