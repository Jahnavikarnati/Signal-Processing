function y = quadratic_quant(x,B,a)
n =  length(x);
y= zeros(1,n);
z=1/2^(B-1);
for k =1:n
    count=1;
    found=0;
    nt=0;
    if x(1,k) < 0
      x(1,k) = -x(1,k);
      nt=1;
    end  
    
 while(found == 0)
     
      if x(1,k)>=a
        if nt==1
            y(1,k)=-(a/2)*(1+(1-z)^2);
        elseif nt==0
            y(1,k)=(a/2)*(1+(1-z)^2);
        end
           found=1;
     end
 
     
   
     if x(1,k) < a*((count/(2^(B-1)))^2)
        
         if nt==1
             y(1,k) = -a*((((count-1)^2)+((count)^2))/(2*(2^((B-1)*2))));
         elseif nt==0
             y(1,k) = a*((((count-1)^2)+((count)^2))/(2*(2^((B-1)*2))));
         end
            found=1; 
         
     else
         count = count +1;
         
     end   
 
 end


 end

end