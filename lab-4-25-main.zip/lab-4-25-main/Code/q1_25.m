% Bit rate for each of the audio signal
bs_1 = 256000;
bs_2 = 512000;
bs_3 = 1411000;
bs_4 = 1411000;

[y1,fs_1] = audioread('file_example_WAV_1MG.wav');
[y2,fs_2] = audioread('file_example_WAV_2MG.wav');
[y3,fs_3] = audioread('file_example_WAV_5MG.wav');
[y4,fs_4] = audioread('file_example_WAV_10MG.wav');

[m1,n1] = size(y1);
[m2,n2] = size(y2);
[m3,n3] = size(y3);
[m4,n4] = size(y4);

%displays the sampling frequencies of the audio signals
disp(fs_1);disp(fs_2);
disp(fs_3);disp(fs_4);

t_1 = (m1/fs_1);
t_2 = (m2/fs_2);
t_3 = (m3/fs_3);
t_4 = (m4/fs_4);

% displays the duration of each audio signal
disp(t_1); disp(t_2);
disp(t_3); disp(t_4);

% Computes the number of bits the Analog to Digital convertor as used while
% quantizing/storing these signals
B_1 = (bs_1/(fs_1*n1));
B_2 = (bs_2/(fs_2*n2));
B_3 = (bs_3/(fs_3*n3));
B_4 = (bs_4/(fs_4*n4));

% displays the number of bits per sample used
disp(B_1); disp(B_2);
disp(B_3); disp(B_4);

% to listen the audiofiles we loaded
% sound(y1,fs_1);
% sound(y2,fs_2);
% sound(y3,fs_3);
% sound(y4,fs_4);

% we will listen to the audiofile1 by lowering the sampling frequency than
% the true sampling frequency(fs_1)
sound(y1,0.8*fs_1);

% we will listen to the audiofile1 by increasing the sampling frequency than
% the true sampling frequency(fs_1)
% sound(y1,1.4*fs_1);

quantization_level1 = 2^B_1;
disp(quantization_level1 );
quantization_level2 = 2^B_3;
disp(quantization_level2);

% Sampling frequencies of the audio signals are  8000,16000,44100,44100
% respectively.
% Duration of each of the audio signals are 33.5296,33.5296,29.6287,58.9936
% respectively.
% Number of bits the ADC has used is 16bits approximately for all the audio
% signals.
% Approximately 65536 levels of quantization this ADC can perform.
% By listening to the sound for the audio file1 by reducing its sampling
% frequency we will be increasing the bit rate  so the audio seems to play fast.
% As we increase the sampling frequency we could obserVe the reverse
% of that when we decrease the sampling frequency the audio seems to play
% slowly this time.
% The fourier Transform property we observe is Scaling property.As we are
% changing the sampling frequency.
 
