syms t
syms xt

T = 1;
%given xt function
xt = t;
N = 20;
t1 = -1/4;
t2 = 1/4;

F = fourierCoeff(t,xt,T,t1,t2,N);
FS_idx = -N:N; 
figure; 
stem(FS_idx, real(F), 'bo'); hold on;
stem(FS_idx, imag(F), 'r*'); 
grid on; 

 
 xlabel('k'); ylabel('ak(Fourier series coefficients)');
 legend('real values','imaginary values')
 title('Plot of Fourier Series Coffecients ')
 
  % From the given graph of x2(t) we can say that the signal is odd signal and we
 % expect the plot to also have odd symmetry for signals having odd symmetry we can say that
 % the coefficients will be imaginary..
 
 % Now run the code and observe the plot4b  % Here we could observe what we expected 
 % that is a_(-k) = -(a_k) and also the coefficients are imaginary..
 % We could say that odd symmetry holds for this example.