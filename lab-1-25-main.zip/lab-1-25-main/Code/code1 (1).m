syms t   % symbolic variable for integration
syms xt  % function of symbolic variable t

xt = 2*cos(2*pi*t) + cos(6*pi*t);
T = 1; % Time period 
N = 5; % Number of Fourier Series coefficients to compute 
% t1 and t2 are the left and right limits 
t1 = -1/2; 
t2 = 1/2;

% fourierCoeff is a function that computes the fourier series coefficients
% of the periodic signal xt
 F = fourierCoeff(t,xt,T,t1,t2,N); % F is vector that contains the fourier series coefficients
 
 % plotting k VS ak(Fourier series coefficients )  
 FS_idx = -N:N;
 figure;stem(FS_idx,F);grid on;
 
 xlabel('k'); ylabel('ak(Fourier series coefficients)');
 title('Plot of Fourier Series Coffecients ')
 
 %%
 syms xt
 syms t
 xt = 1;
 T = 1;
 N = 10;
 t1 = -0.25;
 t2 =  0.25;
 
  F = fourierCoeff(t,xt,T,t1,t2,N); 
 FS_idx = -N:N;
 figure;stem(FS_idx,F);grid on;
 
 xlabel('k'); ylabel('ak(Fourier series coefficients)');
 title('Plot of Fourier Series Coffecients ')
 
 
 % Results
 
 %By running the first section of the code you could observe the plot1.1a
 %in the results folder
 %In the similar way by running the next section of the code you could
 %observe the plot1.1b
 
 % Here the plots represent the Fourier series coefficients of the periodic
 % function





