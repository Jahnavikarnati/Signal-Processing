% This is a function that computes partial Fourier sum of a given vector of
% Fourier series coefficients
function y = partialfouriersum (A, T, time_grid)

a= length(A); % a is the length of A
N= (a-1)/2;   %We will be calculating the value of N from a

y = zeros(size(time_grid)); % returns a vector with zeroes assigned to each value of time_grid
w0=2*pi/T; % calculating fundamental angular frequency from time period(T)

for k = -N:N
    y = y + A(k+N+1)*exp(1i*k*w0*time_grid); % We will be computing y at all the time points in the vector time_grid.

 end

end
