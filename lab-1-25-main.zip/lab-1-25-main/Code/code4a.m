syms t
syms xt

T = 1;
% given xt function 
xt = abs(t);
N = 20;
t1 = -1/4;
t2 = 1/4;

F = fourierCoeff(t,xt,T,t1,t2,N);
 
FS_idx = -N:N;
 figure;stem(FS_idx,F);grid on;
 
 xlabel('k'); ylabel('ak(Fourier series coefficients)');
 title('Plot of Fourier Series Coffecients ')
 
 % From the given graph of x1(t) we can say that the signal is even signal and we
 % expect the plot to also have even symmetry..
 
 % Now run the code and observe the plot4a we could observe as we expected
 % that is a_(-k) = a_k..
 % We could say that even symmetry holds for this example..
