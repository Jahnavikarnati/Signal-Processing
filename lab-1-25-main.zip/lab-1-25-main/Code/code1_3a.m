syms t
xt = 1;
T = 1;
N = 10;
t1 = -0.1;
t2 = 0.1;

F = fourierCoeff(t,xt,T,t1,t2,N); % Computes the Fourier series coefficients for the square wave
disp(F)
FS_idx = -N:N;
plot(FS_idx,F,"-b") %Plotting the Fourier series coefficients(ak) Vs k 
 
 % labelling the plot
 xlabel('k'); ylabel('ak(Fourier series coefficients)');
 title('Plot of Fourier Series Coffecients ')
 
 % By running the code we could observe the plot of the fourier series coefficients(ak) Vs k.
 % We could observe the plot in the plot3a image in the Results folder.
 
