syms t % symbolic variable for integration
xt= 1; % function of symbolic variable t

T=1; % Time period of the above signal
N=10; % Number of Fourier Series coefficients to compute
time_grid = -0.5:0.01:0.5; % a time vector

% integration limits 
t1= -0.1; 
t2= 0.1;

F = fourierCoeff(t, xt,T, t1, t2, N); % F is vector that contains the fourier series coefficients
y = partialfouriersum (F, T, time_grid); % We will be evaluating y at all the time points in the vector time_grid.
fig = figure;
subplot(2,2,1);plot(time_grid,y,"-b"); % plot time_grid Vs y
title('Plot for N=10') 

% We will be plotting the signal for different values of N 
T=1; 
N=50; 
time_grid = -0.5:0.01:0.5; 

t1= -0.1; 
t2= 0.1;
F = fourierCoeff(t, xt,T, t1, t2, N);
y = partialfouriersum (F, T, time_grid);
subplot(2,2,2);plot(time_grid,y,"-g");
title('Plot for N=50') 

T=1; 
N=100; 
time_grid = -0.5:0.01:0.5; 

t1= -0.1; 
t2= 0.1; 
F = fourierCoeff(t, xt,T, t1, t2, N);
y = partialfouriersum (F, T, time_grid);
subplot(2,2,3);plot(time_grid,y,"-r");
title('Plot for N=100') 

%labeling the plots commonly
han=axes(fig,'visible','off'); 
han.XLabel.Visible='on';
han.YLabel.Visible='on';
ylabel(han,'y(t)');
xlabel(han,'time(s)');


% Results
% By running the code we could observe the signals y(t) when N=10,N=50 and N=100.
% We could observe the plot in in the plot3c image in the results folder.
% From the plot we could observe that the reconstructed signal exhibits oscillations or ripples at the discontinuties.
% We could observe that as N increases the ripples move towards the discontinuties.
% From the plots we could say that as N increases the reconstructed signal will be a better approximation for the orginal signal.
% From the above results and from the plot's we can say it is Gibb's Phenomenon.
