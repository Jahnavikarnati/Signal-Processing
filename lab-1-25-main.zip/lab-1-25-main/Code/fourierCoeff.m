function [F] = fourierCoeff(t,xt,T,t1,t2,N)
% THIS FUNCTION OUTPUT COLUMN VECTOR OF 2N+1 values successively 
% a(-N) TO a(+N) FOURIER COEFFICIENTS.

F = zeros((2*N)+1,1);
for nn = -N:N
    F(nn+N+1) = 1/T * int(xt * exp(-1i*nn*2*pi*t/T), t,t1,t2); % ak is fourier coefficient

end

