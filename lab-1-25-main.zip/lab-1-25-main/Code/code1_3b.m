syms t
xt = 1;
T = 1;
N = 10*T;
t1 = -0.1;
t2 = 0.1;

% Computing the values of ( Fourier series coefficients*time period) for the the given signal xt for different values of T.
F = T*fourierCoeff(t,xt,T,t1,t2,N); % fourierCoeff is a function that gives the values of fourier series coefficients for the signal xt.
FS_idx = -N:N;
fig = figure;
subplot(2,2,1);plot(FS_idx,F,"-g") %ploting the fourier series coefficients(ak) Vs k
title('Plot for T=1') 

T = 10;
N = 10*T;
t1 = -0.1;
t2 = 0.1;

F = T*fourierCoeff(t,xt,T,t1,t2,N); 
FS_idx = -N:N;
subplot(2,2,2);plot(FS_idx,F,"-b")
title('Plot for T=10') 


T = 20;
N = 10*T;
t1 = -0.1;
t2 = 0.1;

F = T*fourierCoeff(t,xt,T,t1,t2,N); 
FS_idx = -N:N;
subplot(2,2,3);plot(FS_idx,F,"-g")
title('Plot for T=20') 


T = 50;
N = 10*T;
t1 = -0.1;
t2 = 0.1;

F = T*fourierCoeff(t,xt,T,t1,t2,N); 
FS_idx = -N:N;
subplot(2,2,4);plot(FS_idx,F,"-r")
title('Plot for T=50') 

% Labelling the plots commonly
han=axes(fig,'visible','off'); 
han.XLabel.Visible='on';
han.YLabel.Visible='on';
ylabel(han,'T*ak');
xlabel(han,'k');


% Results
% By running the code we could observe the Fourier series coefficients of the signal for different values of time period for T=10, T=20 and T=50.
% We get the plot as in the plot3b image inn the Results folder.
% From the plot we can say that as T is increasing the envelope is sampled with a closer and closer spacing.
% As T increases we could observe that the Fourier series coefficients, multiplied by T, become more and more closely spaced samples of the envelope. 
% And the set of Fourier series coefficients approaches the envelope function(sinc function) as T -> oo.



 
