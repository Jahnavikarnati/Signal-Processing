syms t % symbolic variable for integration
xt= 2*cos(2*pi*t)+cos(6*pi*t); % function of symbolic variable t

T=1; % Time period of the above signal
N=5; % Number of Fourier Series coefficients to compute
time_grid = -0.5:0.01:0.5; % a time vector

% integration limits 
t1= -1/2; 
t2= 1/2;



F = fourierCoeff(t, xt,T, t1, t2, N); % F is vector that contains the fourier series coefficients
y = partialfouriersum (F, T, time_grid); % We will be evaluating y at all the time points in the vector time_grid.

plot(time_grid,y,"-b"); % plot time_grid Vs y
hold on 

x1t = 2*cos(2*pi*time_grid)+cos(6*pi*time_grid) ; %in the same graph we will be plotting the orginal signal
plot(time_grid, x1t,"-r");
hold off

xlabel('time(s)');
ylabel('Signal x(t) and y(t)');
legend('Reconstructed Signal','Orginal signal')
title('Plot for Reconstructed and Orginal signal')

% Calculating the maximum absolute error between reconstructed and orginal signals 
MAE = max(abs(y-x1t));
disp(MAE)
% Calculating the Root mean square error between reconstructed and orginal signals
RMS = sqrt(mean(y-x1t).^2);
disp(RMS)



% Results
% By running the code we could observe that the reconstructed signal and
% the orginal signal are getting overlapped you could verify by seeing the
% values Maximum absolute error(MAE) and Root mean square error(RMS).

% We could observe that RMS value is zero and the value of MAE is very
% very small such that it could be neglected.
% So from the observations we can say that the reconstructed and the
% orginal signals overlap.

