% partb
syms t; % symbolic variable

a = -2;
b = 2;
w = -5:0.1:5; 
xt = 1;

X = continousFT(t,xt,a,b,w); % we will be computing the fourier transform for the given signal xt.

% Plotting the real part, imaginary part, absolute value and phase of the computed fourier transform as a function of w.
subplot(2,2,1); plot(w,real(X),"-b")
title('plotting the real part of X Vs w');
ylabel('real part of X');xlabel('w');

subplot(2,2,2); plot(w,imag(X),"-g")
title('plotting the imaginary part of X Vs w');
ylabel('imaginary part of X');xlabel('w');

subplot(2,2,3); plot(w,abs(X),"-r")
title('Absolute value of X Vs w');
ylabel('absolute value of X');xlabel('w');

subplot(2,2,4); plot(w,angle(X),"-b")
title('Phase of the computed FT Vs w');
ylabel('phase of the computed FT');xlabel('w');

sgtitle('When xt is a rectangular pulse and T=2')

% When we run the code you could observe the plots.
% We can say that xt is an rectangular pulse. We know that for a rectangular pulse we get a sinc function as a fourier transform. So we can say that the imaginary part will be 0.
% By observing the plots we can say that the imaginary part is zero and the plot of real part will look same as the sinc function graph.
% Plot for the Phase of the computed FT Vs w will be like a rectangular pulse train as the imaginary part is 0 the phase will 0 if X is positive and pi if X is negative.

%%
% partc
syms t;

a = -4;
b = 4;
w = -5:0.1:5;
xt = 1;

X = continousFT(t,xt,a,b,w);

subplot(2,2,1); plot(w,real(X),"-b")
title('plotting the real part of X Vs w');
ylabel('real part of X');xlabel('w');

subplot(2,2,2); plot(w,imag(X),"-g")
title('plotting the imaginary part of X Vs w');
ylabel('imaginary part of X');xlabel('w');

subplot(2,2,3); plot(w,abs(X),"-r")
title('Absolute value of X Vs w');
ylabel('absolute value of X');xlabel('w');

subplot(2,2,4); plot(w,angle(X),"-b")
title('Phase of the computed FT Vs w');
ylabel('phase of the computed FT');xlabel('w');

sgtitle('When xt is a rectangular pulse and T=4')

% Here when we change the value of T we can see that the magnitude remains same but only the phase changes.
% Here we could support our observations by 'time shift' property of Fourier Transform.

%%
% partd
syms t;

a = -pi;
b = pi;
w = -5:0.1:5;
% xt = e(1j*t);
xt = cos(t);

X = continousFT(t,xt,a,b,w);

subplot(2,2,1); plot(w,real(X),"-b")
title('plotting the real part of X Vs w');
ylabel('real part of X');xlabel('w');

subplot(2,2,2); plot(w,imag(X),"-g")
title('plotting the imaginary part of X Vs w');
ylabel('imaginary part of X');xlabel('w');

subplot(2,2,3); plot(w,abs(X),"-r")
title('Absolute value of X Vs w');
ylabel('absolute value of X');xlabel('w');

subplot(2,2,4); plot(w,angle(X),"-b")
title('Phase of the computed FT Vs w');
ylabel('phase of the computed FT');xlabel('w');

sgtitle('When xt is cos(t)')

% When xt is e^jt we expect the graph similar to sinc function with frequency shift of 1. Here we could observe the 'Frequency shift' property of fourier transform.We could observe the same in the plot.
% When xt is cos(t) we expect the Fourier transform to be real and even as xt is real and even.We could observe the same in the plot.
% Also we observe multiple curves in the plot of cos(t) as we get the FT of
% cos(t) as sum of two sinc functions.

%%
% parte
syms t;

a = -2;
b = 2;
w = -5:0.1:5;
xt = 1- abs(t);

X = continousFT(t,xt,a,b,w);

subplot(2,2,1); plot(w,real(X),"-b")
title('plotting the real part of X Vs w');
ylabel('real part of X');xlabel('w');

subplot(2,2,2); plot(w,imag(X),"-g")
title('plotting the imaginary part of X Vs w');
ylabel('imaginary part of X');xlabel('w');

subplot(2,2,3); plot(w,abs(X),"-r")
title('Absolute value of X Vs w');
ylabel('absolute value of X');xlabel('w');

subplot(2,2,4); plot(w,angle(X),"-b")
title('Phase of the computed FT Vs w');
ylabel('phase of the computed FT');xlabel('w');

sgtitle('When xt is a triangular pulse')
% Here we would be expressing the triangular pulse as 1-abs(t) we could
% also express it as convolution of two rectangular pulses.
% We would expect the imaginary part of X(w) to be zero as x(t) is a real
% and even.We would observe multiple curves while plotting real part of
% X(w) with w as FT (X(w)) of the given signal will be sum of 3 sinc
% functions.
