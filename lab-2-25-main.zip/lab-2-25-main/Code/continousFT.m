function X = continousFT(t,xt,a,b,w)

X = int(xt*exp(-1i*w*t),t,a,b); 

   
end

% This is a function called continousFT that returns a vector X which contains the fourier transform of xt for each of the frequencies in input vector w.
% The function numerically computes the fourier transform of the given signal xt which has finite support in [a,b] and zero outside.

