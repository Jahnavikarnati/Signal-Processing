function B = myHPF(A,w0_FS,wc)
N = (length(A)-1)/2;
B = zeros(length(A),1);


for k = 1:length(A)
    if w0_FS*abs(k-1-N) <= wc
        B(k) = 0;
    
    elseif w0_FS*abs(k-1-N) > wc
        B(k) = A(k);
    
   end
    
end


end

% We wil be finding the Fourier series coeffiecients for a output signal
% when an input signal with coefficients in A are passed through high pass
% filter. If we observe we can say that H(w) will be reverse of the LPF case.

