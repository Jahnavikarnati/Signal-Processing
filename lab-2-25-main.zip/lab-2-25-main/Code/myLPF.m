function B = myLPF(A,w0_FS,wc)
N = (length(A)-1)/2;
B = zeros(length(A),1);


for k = 1:length(A)
    if w0_FS*abs(k-1-N) > wc
        B(k) = 0;
    
    elseif w0_FS*abs(k-1-N) <= wc
        B(k) = A(k);
    
   end
    
end


end

% Here in this function we will be finding the Fourier Series Coefficients for the output signal  when an input signal with coefficients in A are passed through an ideal low pass filter.
