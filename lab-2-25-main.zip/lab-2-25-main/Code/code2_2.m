% partb

syms t % symbolic variable

T = 2*pi; 
t = -2*T:0.01:2*T;
N = 5;
x = 2*N+1;
A = zeros(x,1);
% giving the Fourier series coefficents as input to A
A(N) = 0.5;
A(N+2) = 0.5;
w0_FS = 1;
wc = 0.5; % cut-off frequency

xt = partialfouriersum(A,T,t); % will be computing the x(t) signal

B = myLPF(A,w0_FS,wc); % The output signal when a signal with FS coefficients are passed to a LPF is computed

Y = partialfouriersum(B,T,t); % will be computing the output signal from its FS coefficients.

% We will be plotting x(t) and y(t) VS time(s)
figure(1);
subplot(2,1,1); plot(t,xt,"-b")
xlabel('time(s)'); ylabel('x(t)')
title('x(t) graph')
subplot(2,1,2); plot(t,Y,"-r")
xlabel('time(s)'); ylabel('y(t)')
title('y(t) graph')

sgtitle('signal x(t) = cos(t) Low pass filtered with cutoff frequency wc=0.5')

% When we pass x(t) = cos(t) through a low pass filter we get y(t) same as
% x(t) for wc=2. And y(t) will be zero in case of wc=0.5.

%%
% partc
syms t

T = 2*pi;
t = -2*T:0.01:2*T;
N = 5;
x = 2*N+1;
A = zeros(x,1);
A(N) = 0.5;
A(N+2) = 0.5;
w0_FS = 1;
wc = 0.5;

xt = partialfouriersum(A,T,t);

B = myHPF(A,w0_FS,wc);

Y = partialfouriersum(B,T,t);

figure(1);
subplot(2,1,1); plot(t,xt,"-b")
xlabel('time(s)'); ylabel('x(t)')
title('x(t) graph')
subplot(2,1,2); plot(t,Y,"-r")
xlabel('time(s)'); ylabel('y(t)')
title('y(t) graph')

sgtitle('signal x(t) = cos(t) High pass filterd with cutoff frequency wc=0.5')

% When we pass x(t) = cos(t) through a high pass filter we get y(t) zero
% for wc=2. And y(t) will be same as x(t) in case of wc=0.5.
% From the observations of the plots we could say that it
% is the reverse when a signal is passed through LPF.
%%
% partd

syms t % symbolic variable

T = 2*pi; 
t = -2*T:0.01:2*T;
N = 5;
x = 2*N+1;
A = zeros(x,1);
% giving the Fourier series coefficents as input to A
A(N) = 0.5;
A(N+2) = 0.5;
w0_FS = 1;
G =1; a =1;

xt = partialfouriersum(A,T,t); % will be computing the x(t) signal

B = NonIdeal(A,w0_FS,G,a); % The output signal when a signal with FS coefficients are passed to a LPF is computed

Y = partialfouriersum(B,T,t); % will be computing the output signal from its FS coefficients.

% We will be plotting x(t) and y(t) VS time(s)
figure(1);
subplot(2,1,1); plot(t,xt,"-b")
xlabel('time(s)'); ylabel('x(t)')
title('x(t) graph')
subplot(2,1,2); plot(t,Y,"-r")
xlabel('time(s)'); ylabel('y(t)')
title('y(t) graph')

sgtitle('signal x(t) = cos(t) filtered with Non ideal Low pass filter')

% Here we take a complex-valued nature of LTI system frequency response
% from the plot we can say that it has an effect on the phase of the output
% signal. From the observations we can say that the output signal is a cos
% function with change in phase and magnitude.

%%
% parte

syms t

T = 2*pi;
t = -2*T:0.01:2*T;
N = 5;
x = 2*N+1;
A = zeros(x,1);
A(N-2) = 0.5;
A(N-1) = 0.5*1i;
A(N+3) = -0.5*1i;
A(N+4) = 0.5;
w0_FS = 1;
wc = 2.5;

xt = partialfouriersum(A,T,t);

B = myHPF(A,w0_FS,wc);

Y = partialfouriersum(B,T,t);

figure(1);
subplot(2,1,1); plot(t,xt,"-b")
xlabel('time(s)'); ylabel('x(t)')
title('x(t) graph')
subplot(2,1,2); plot(t,Y,"-r")
xlabel('time(s)'); ylabel('y(t)')
title('y(t) graph')

sgtitle('signal x(t) = sin(2t)+cos(3t) High pass filtered with wc=0.25')

% We would be plotting the graph of y(t) and x(t) here you could see that
% both are not similar.And there will be imaginary parts for x(t) and y(t).




