function F = NonIdeal(A,w0_FS,G,a)

N = length(A);
F = zeros(N,1);

for m = 1:N
    k = m -1 -(N-1)/2;
    
    F(m) = A(m)*(G/(a+1i*k*w0_FS));
end
end

% Here we will be taking a Non ideal low pass filter.
% We wil be finding the Fourier series coeffiecients for a output signal
% when an input signal with coefficients in A are passed through Non Ideal low pass
% filter.