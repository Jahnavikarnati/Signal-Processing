%part a

x = -1.5:0.01:1.5;
y = x;
[X,Y] = meshgrid(x, y);
z = X + (1j*Y) ;
figure(1);
p=0.9;
xz = z./(z-p);
r = log(abs(xz));
% will be ploting the log|X(z)| in 3d plane for p=0.9
mesh(X,Y,r);
xlabel('Re(z)');ylabel('Imag(z)');zlabel('log|X(z)|')
title('For p=0.9')
rotate3d on;

figure(2);
p=1+1j;
xz = z./(z-p);
r = log(abs(xz));
% will be ploting the log|X(z)| in 3d plane for p=1+j
mesh(X,Y,r);
xlabel('Re(z)');ylabel('Imag(z)');zlabel('log|X(z)|')
title('For p = 1+j')
rotate3d on;


%%
% part b
a = [1,-0.9];
% we will be using the zplane command to generate a pole zero plot 
subplot(2,1,1);zplane(1,a);
title('For p=0.9');

a = [1,-(1+1j)];
subplot(2,1,2);zplane(1,a);
title('For p=1+j');
%%
% part c
% We will be computing the DTFT of X(z) using freqz command
n = 1001;
a = [1, -0.9];
[x1n,w] = freqz(1,a,n);
subplot(2,1,1);plot(w,abs(x1n));
xlabel('w')
title('Magnitude of frequency response for p = 0.9')

a = [1, -(1+1j)];
[x2n,w] = freqz(1,a,n);
subplot(2,1,2);plot(w,abs(x2n));
xlabel('w')
title( 'Magnitude of frequency response for p = 1+j');

%%
%partd
% impz command gives the impulse response of the given X(z) for p=0.9 and p= 1+j
n = 51;
a = [1, -0.9];
[h,t]= impz(1,a,n);
subplot(2,1,1);plot(t,h);
xlabel('t');ylabel('Impulse response')
title('For p = 0.9')

a = [1, -(1+1j)];
[h2,t] = impz(1,a,n);
subplot(2,1,2);plot(t,abs(h2));
xlabel('t');ylabel('Magnitude of impulse response')
title('For p = 1+j')


%%
%part e


r = 0.95;
w = pi/3;
b = [1, -(2*cos(w)) , 1];
a = [1, -(2*r*cos(w)), r^2 ];

x = -1.5:0.01:1.5;
y = x;
[X,Y] = meshgrid(x, y);
z = X + (1j*Y) ;
figure(1);
num = (z.^2 - (2*cos(w).*z) +1);
denom = (z.^2-(2*r*cos(w)).*z + r^2);
xz = num./denom;
r = log(abs(xz));
mesh(X,Y,r);
xlabel('Re(z)');ylabel('Imag(z)');zlabel('log|X(z)|')
rotate3d on;


figure(2);
subplot(2,2,1);zplane(b,a);

n = 1001;
[x1n,w] = freqz(b,a,n);
subplot(2,2,2);plot(w,abs(x1n));
xlabel('w')
ylabel('H(w)(frequency response)')

n = 51;
[h,t] = impz(b,a,n);
subplot(2,2,3);plot(t,h);
xlabel('t');ylabel('Impulse response')
