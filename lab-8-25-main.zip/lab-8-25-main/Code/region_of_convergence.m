function [N,ROC,ROC_zero]   = region_of_convergence(p)
p = abs(p); % computes the magnitude of each element in the vector p and stores in p
p = unique(p); % it computes the unique elements in the vector p 
p = sort(p);   % Then it sorts the elements in ascending order
y = ismember(0,p); % Checks whether 0 is present in p or not, if 0 is present then it returns 1 otherwise 0
k = length(p);
if(y==0) % if zero is not present in p
N = k+1; % Then number of ROC possibile will be k+1
ROC = zeros(N,2);
ROC(N,2) = inf;
% Computes ROC a N*2 matrix
for m = 1:N-1
    ROC(m,2) = p(m);
    ROC(m+1,1) = ROC(m,2);
end
ROC_zero = 1; % As zero is not a pole we can tell that any one of the possibile ROC contains zero.
%if 0 is present in p
else
    N = k; % Then number of ROC possibile will be k+1
    ROC = zeros(N,2);
    ROC(N,2) = inf;
% Computes ROC a N*2 matrix
if(N~=1)
for m = 1:N-1
    ROC(m,2) = p(m+1);
    ROC(m+1,1) = ROC(m,2);
end
end
   ROC_zero = 0; % as 0 is a possibile in this case we can say that no ROC contains 0
end
    
end