%Script that calls the function region_of_convergence for each input and
%displays the output.

p1 = 0.2;
[N,ROC,ROC_zero]   = region_of_convergence(p1);
disp("For p = " );
disp(p1);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p2 = 0;
[N,ROC,ROC_zero]   = region_of_convergence(p2);
disp("For p = " );
disp(p2);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p3 = [0,0.75];
[N,ROC,ROC_zero]   = region_of_convergence(p3);
disp("For p = " );
disp(p3);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p4 = [1,-0.75];
[N,ROC,ROC_zero]   = region_of_convergence(p4);
disp("For p = " );
disp(p4);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p5 = [0.75,-0.75];
[N,ROC,ROC_zero]   = region_of_convergence(p5);
disp("For p = " );
disp(p5);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p6 = [3,3,3];
[N,ROC,ROC_zero]   = region_of_convergence(p6);
disp("For p = " );
disp(p6);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p7 = [0,1,2];
[N,ROC,ROC_zero]   = region_of_convergence(p7);
disp("For p = " );
disp(p7);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p8 = [-0.5,1j];
[N,ROC,ROC_zero]   = region_of_convergence(p8);
disp("For p = " );
disp(p8);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p9 = [0,1j,-1j];
[N,ROC,ROC_zero]   = region_of_convergence(p9);
disp("For p = " );
disp(p9);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p10 = [1,-1,2-1j,2+1j];
[N,ROC,ROC_zero]   = region_of_convergence(p10);
disp("For p = " );
disp(p10);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p11 = [1-1j,2-1j,1-3j,2-1j];
[N,ROC,ROC_zero]  = region_of_convergence(p11);
disp("For p = " );
disp(p11);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

p12 = [1,-1,1j,-1j];
[N,ROC,ROC_zero]   = region_of_convergence(p12);
disp("For p = " );
disp(p12);
disp("N = " + N);
disp("ROC = " );
disp(ROC);
disp("ROC_zero = " + ROC_zero);

